### Maven

This plugin lets you query maven repositories for artifacts; then see the available versions, javadoc and source.