### A D3 force graph directive.

Refer to the [user guide](doc/README.md) or to [this blog](http://www.wayofquality.de/index.php/blog/entry/creating-a-directive-for-hawtio) if you are interested to read a bit about the inner workings of the directive code.
