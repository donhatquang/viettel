### UI

The **UI** plugin provides a number of [AngularJS](http://angularjs.org/) directives for creating a number of UI widgets.  The following examples can be edited and are re-compiled on the fly.

For details on form widgets take a look at the [Form documentation](index.html#/help/forms/developer)

## General UI widgets
<div ng-include="'app/ui/html/test.html'"></div>



