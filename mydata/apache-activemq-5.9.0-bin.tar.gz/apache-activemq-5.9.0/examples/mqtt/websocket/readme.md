## Overview

This is an example of how use the 
['stomp-websocket'](https://github.com/jmesnil/stomp-websocket) 
JavaScript APIs with the ActiveMQ message broker.

## Prereqs

- Use a modern browser with WebSocket support like Chrome or WebKit

## Running

Run the ActiveMQ sever locally and then open the `index.html`
in the current directory using a web browser.

## Credits

This example is a modified version of Jeff Mesnil's chat example.