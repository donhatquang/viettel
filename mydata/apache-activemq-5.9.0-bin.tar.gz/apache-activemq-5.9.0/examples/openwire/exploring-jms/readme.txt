FuseSource distribution of ActiveMQ - Exploring JMS v1.1
========================================================
The Exploring JMS Samples are a described in the "Exploring JMS with 
the FuseSource distribution of ActiveMQ" book available from fusesource.com.

They demonstrate how to use the JMS client APIs to accomplish basic messaging 
tasks.

The build.xml file provides targets for rebuilding the examples and for 
launching them.